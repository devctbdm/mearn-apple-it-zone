var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1ln9dif._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_[___path]_route_actions_1xh_5e2.js")
R.m(132001)
module.exports=R.m(132001).exports
